<!DOCTYPE html>
<html lang="en">
    

<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>UBa HMS - Login</title>
		
		<!-- Favicon -->
		<a class="navbar-brand brand-logo mr-5" href="#"><img width="100" style="height: 80%;" src="<?php echo base_url(); ?>vendor/image/about.png" alt="logo"/></a>
        <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/lib/img/favicon.png">
	
		<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,500;0,600;0,700;1,400&amp;display=swap">

		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/lib/plugins/bootstrap/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/lib/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/lib/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/lib/css/style.css">
    </head>
    <body>
	
		<!-- Main Wrapper -->
        <a href="<?php echo base_url('index.php/Indexcontroller/medical/'.$id) ?>"></a>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="<?php echo base_url(); ?>assets/lib/js/jquery-3.5.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?php echo base_url(); ?>assets/lib/js/popper.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/lib/plugins/bootstrap/js/bootstrap.min.js"></script>
		
		<!-- Custom JS -->
		<script src="<?php echo base_url(); ?>assets/lib/js/script.js"></script>
		
    </body>

<!-- Mirrored from preschool.dreamguystech.com/html-template/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 23 Feb 2021 07:07:46 GMT -->
</html>